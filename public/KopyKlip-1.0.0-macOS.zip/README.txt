==========================================================
   KopyKlip for macOS (Apple Silicon M1/M2/M3 Native)
==========================================================

HOW TO INSTALL:
1. Drag "KopyKlip.app" into /Applications
   (or double-click "Install_KopyKlip.command")
2. The 📎 icon will appear in your top Mac Menu Bar!
