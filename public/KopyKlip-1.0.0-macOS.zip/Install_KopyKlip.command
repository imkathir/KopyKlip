#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
echo "=========================================================="
echo "  Installing KopyKlip into /Applications on Apple Silicon..."
echo "=========================================================="
killall KopyKlip 2>/dev/null || true
cp -R "$DIR/KopyKlip.app" /Applications/
chmod +x /Applications/KopyKlip.app/Contents/MacOS/KopyKlip
xattr -cr /Applications/KopyKlip.app 2>/dev/null || true
echo "Starting KopyKlip in your top Mac Menu Bar..."
open /Applications/KopyKlip.app
echo "Look for the 📎 paperclip icon at the very top of your screen!"
